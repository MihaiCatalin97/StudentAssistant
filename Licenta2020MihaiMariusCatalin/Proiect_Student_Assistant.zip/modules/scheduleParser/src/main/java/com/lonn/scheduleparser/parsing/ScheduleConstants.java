package com.lonn.scheduleparser.parsing;

public class ScheduleConstants {
	public static final String PROFESSORS_PAGE = "https://profs.info.uaic.ro/~orar/orar_profesori.html";
	public static final String COURSES_PAGE = "https://profs.info.uaic.ro/~orar/orar_discipline.html";
	public static final Integer CURRENT_SEMESTER = 1;
}
