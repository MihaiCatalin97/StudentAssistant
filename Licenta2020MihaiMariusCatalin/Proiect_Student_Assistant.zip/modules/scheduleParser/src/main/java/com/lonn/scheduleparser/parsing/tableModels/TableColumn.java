package com.lonn.scheduleparser.parsing.tableModels;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class TableColumn {
	private Integer columnIndex;
}
