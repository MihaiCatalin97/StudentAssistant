package com.lonn.studentassistant.views.implementations.category;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class ScrollViewCategoryHeader extends LinearLayout {

	public ScrollViewCategoryHeader(Context context) {
		super(context);
	}

	public ScrollViewCategoryHeader(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
}
