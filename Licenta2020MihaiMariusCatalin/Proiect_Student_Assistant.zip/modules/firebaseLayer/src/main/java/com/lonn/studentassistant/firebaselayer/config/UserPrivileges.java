package com.lonn.studentassistant.firebaselayer.config;

public enum UserPrivileges {
	STUDENT,
	PROFESSOR,
	ADMINISTRATOR
}
