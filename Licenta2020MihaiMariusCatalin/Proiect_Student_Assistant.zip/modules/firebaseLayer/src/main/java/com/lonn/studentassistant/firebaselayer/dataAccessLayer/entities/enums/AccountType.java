package com.lonn.studentassistant.firebaselayer.dataAccessLayer.entities.enums;

public enum AccountType {
	STUDENT,
	PROFESSOR,
	ADMINISTRATOR;
}
